var searchData=
[
  ['fileversion_830',['fileVersion',['../sprite_8h.html#a6ac1f454a7d4e4d64b7ff8ca39ac5920',1,'sprite.h']]],
  ['firstposition_831',['firstPosition',['../structns_box_1_1_box.html#a2e010b1d2352205ffd1fa02b5a210939',1,'nsBox::Box']]]
];
