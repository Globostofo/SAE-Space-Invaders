var searchData=
[
  ['score_900',['score',['../structns_space_invaders_1_1_data.html#a058c560fbb773c2f740fe8109b3b5c84',1,'nsSpaceInvaders::Data']]],
  ['secondposition_901',['secondPosition',['../structns_box_1_1_box.html#a0d4b65421836738e61d521716bb45fe7',1,'nsBox::Box']]],
  ['shieldsprite1_902',['shieldSprite1',['../namespacens_consts.html#acf8f71db1337e377842871cd9609616e',1,'nsConsts']]],
  ['shieldsprite2_903',['shieldSprite2',['../namespacens_consts.html#acdc46dd68660f61d2141c1222d208514',1,'nsConsts']]],
  ['speed_904',['speed',['../structns_entity_1_1_entity.html#a21c26ebd42a46b91f4cf9fa37217adb6',1,'nsEntity::Entity']]],
  ['sprite_905',['sprite',['../structns_entity_1_1_entity.html#ae73ffe3b4782805a53a6b0268d9da13c',1,'nsEntity::Entity']]],
  ['spritesize_906',['spriteSize',['../structns_entity_1_1_entity.html#a72eabdba5b615c1aac2ec45ab12001f9',1,'nsEntity::Entity']]],
  ['state_907',['state',['../structns_event_1_1_mouse_click_data__t.html#a81252b916361dc4deab0f42510fdc928',1,'nsEvent::MouseClickData_t']]]
];
