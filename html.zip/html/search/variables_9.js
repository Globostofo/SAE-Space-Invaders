var searchData=
[
  ['lastshot_862',['lastShot',['../structns_space_invaders_1_1_data.html#a02c915d52a7d42127b96400b0ef744cb',1,'nsSpaceInvaders::Data']]],
  ['leaderboard_863',['leaderboard',['../namespacens_consts.html#ac2264e044df4cc01cc820abf330dce35',1,'nsConsts']]],
  ['levelclear_864',['levelClear',['../namespacens_consts.html#a5a8238c711353133489534e292d43295',1,'nsConsts']]],
  ['lifepoints_865',['lifePoints',['../structns_entity_1_1_entity.html#a031969af2e8c25b4ba915be2804bcb15',1,'nsEntity::Entity']]],
  ['lifepointsremaining_866',['lifePointsRemaining',['../structns_space_invaders_1_1_data.html#af7ac8b7439caecb6001b80146600f66b',1,'nsSpaceInvaders::Data']]]
];
