var searchData=
[
  ['datamagic_824',['datamagic',['../sprite_8h.html#a43e5468a3d445613419004493d2ffac8',1,'sprite.h']]],
  ['direction_825',['direction',['../structns_entity_1_1_entity.html#a47ea0f907e90b3d2feda78014ee92c8b',1,'nsEntity::Entity']]]
];
