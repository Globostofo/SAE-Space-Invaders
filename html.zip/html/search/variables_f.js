var searchData=
[
  ['text_908',['text',['../structns_button_1_1_button.html#a23cc6adc3c501501a689c78350474ada',1,'nsButton::Button']]],
  ['textcolor_909',['textColor',['../namespacens_consts.html#a69df44021873a6851ba91ae37cd79eaa',1,'nsConsts']]],
  ['textfont_910',['textFont',['../namespacens_consts.html#a52815c5cad9b965e948266d642c9b15b',1,'nsConsts']]],
  ['texts_911',['texts',['../structns_scene_1_1_scene.html#a0101ec00fef1e943982f6308468a2f6c',1,'nsScene::Scene']]],
  ['type_912',['type',['../structns_entity_1_1_entity.html#a1d7a31f6e5b1df524bd5a1e06a626bca',1,'nsEntity::Entity']]]
];
