var searchData=
[
  ['headmagic_832',['headmagic',['../sprite_8h.html#a7815e2193b5dea24aae35f568006be9a',1,'sprite.h']]]
];
