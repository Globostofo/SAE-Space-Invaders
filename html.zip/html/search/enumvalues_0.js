var searchData=
[
  ['alignh_5fcenter_929',['ALIGNH_CENTER',['../classns_gui_1_1_text.html#a78bb37c174a4f37eec2b7d69459ee7dca79703335d1d5367bd5ee2387413c17a9',1,'nsGui::Text']]],
  ['alignh_5fleft_930',['ALIGNH_LEFT',['../classns_gui_1_1_text.html#a78bb37c174a4f37eec2b7d69459ee7dca7b5a51aac14cb50d1840e3f3de485ac2',1,'nsGui::Text']]],
  ['alignh_5fright_931',['ALIGNH_RIGHT',['../classns_gui_1_1_text.html#a78bb37c174a4f37eec2b7d69459ee7dca464315bc1bcc242334d76eb8b0d1e8f6',1,'nsGui::Text']]],
  ['alignv_5fbottom_932',['ALIGNV_BOTTOM',['../classns_gui_1_1_text.html#a3b0b5071a55982d5612c457a832f80faace396f1024afc2c37173ea637856e25f',1,'nsGui::Text']]],
  ['alignv_5fcenter_933',['ALIGNV_CENTER',['../classns_gui_1_1_text.html#a3b0b5071a55982d5612c457a832f80faa37d3b49647821b7b1808dcd159867a45',1,'nsGui::Text']]],
  ['alignv_5ftop_934',['ALIGNV_TOP',['../classns_gui_1_1_text.html#a3b0b5071a55982d5612c457a832f80faa3cfba6c9f9e078a9fcd6c4133ecb4c30',1,'nsGui::Text']]]
];
