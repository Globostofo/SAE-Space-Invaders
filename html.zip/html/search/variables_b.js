var searchData=
[
  ['nblifes_882',['nbLifes',['../namespacens_consts.html#a6daf4501e26cef6e648ae0cc33b0ef6d',1,'nsConsts']]],
  ['nbofcolumnsinvaders_883',['nbOfColumnsInvaders',['../namespacens_consts.html#ab67d23b062e8228c4495e2bc67374129',1,'nsConsts']]],
  ['nbofrowsinvaders_884',['nbOfRowsInvaders',['../namespacens_consts.html#a0435a5d05df91c80cf5d3c40cc7b5607',1,'nsConsts']]],
  ['nbofshields_885',['nbOfShields',['../namespacens_consts.html#a944c9825cd58bdb1a383e5fba6c999d5',1,'nsConsts']]]
];
