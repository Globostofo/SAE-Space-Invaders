# SAE 102 - Space Invaders
G1_A - CECCARELLI Luca / CLEMENT Romain / SAADI Nils / VALLS Marion

## Présentation
Le projet de la SAE 102 est un Space Invaders développé par le G1_A

## Comment lancer l'application ?
Lorsque vous avez télécharger le contenu du projet, il suffit de build le projet avec QT une première fois et de glisser le dossier `res` dans le dossier build qui vient d'être créé. Et c'est parti :)

## Comment jouer
Le but du jeu est simple, il faut survivre le plus longtemps possible à des hordes d'envahisseurs pour remporter le plus de points possible. Pour ce faire vous devez tirer des projectiles pour empêcher les envahisseur d'avancer. A chaque horde d'envahisseur terrassée, une nouvelle apparaît aussitôt contenant plus d'envahisseurs qui sont plus rapides.  
Une fois mort, vous pourrez choisir un nom à écrire dans le tableau des records et ainsi inscrire votre nom dans l'histoire !
